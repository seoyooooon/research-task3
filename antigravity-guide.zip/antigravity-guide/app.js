document.addEventListener('DOMContentLoaded', () => {
    
    /* ==========================================================================
       1. Navigation and Routing Logic
       ========================================================================== */
    const sidebar = document.getElementById('sidebar');
    const sidebarLinks = document.querySelectorAll('.sidebar-nav li');
    const sections = document.querySelectorAll('.guide-section');
    const openSidebarBtn = document.getElementById('openSidebarBtn');
    const closeSidebarBtn = document.getElementById('closeSidebarBtn');

    // Sidebar navigation click handler
    sidebarLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            // Close mobile sidebar if open
            sidebar.classList.remove('open');

            const targetId = link.getAttribute('data-target');
            if (targetId) {
                // Switch active tab indicator
                sidebarLinks.forEach(item => item.classList.remove('active'));
                link.classList.add('active');

                // Switch active section
                sections.forEach(section => {
                    if (section.id === targetId) {
                        section.classList.add('active');
                    } else {
                        section.classList.remove('active');
                    }
                });
                
                // Smooth scroll to top of page
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        });
    });

    // Mobile Sidebar toggle buttons
    if (openSidebarBtn) {
        openSidebarBtn.addEventListener('click', () => {
            sidebar.classList.add('open');
        });
    }

    if (closeSidebarBtn) {
        closeSidebarBtn.addEventListener('click', () => {
            sidebar.classList.remove('open');
        });
    }

    // Handle hash links on direct load
    const handleHashLink = () => {
        const hash = window.location.hash.substring(1);
        if (hash) {
            const targetLink = document.querySelector(`.sidebar-nav li[data-target="${hash}"]`);
            if (targetLink) {
                targetLink.click();
            }
        }
    };
    
    window.addEventListener('hashchange', handleHashLink);
    handleHashLink();


    /* ==========================================================================
       2. Artifacts Formatting Previewer Logic
       ========================================================================== */
    const previewTabs = document.querySelectorAll('.preview-tab');
    const formatPanes = document.querySelectorAll('.format-pane');

    previewTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const format = tab.getAttribute('data-format');
            
            // Switch active tab class
            previewTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            // Switch active pane
            formatPanes.forEach(pane => {
                if (pane.id === `pane-${format}`) {
                    pane.classList.add('active');
                } else {
                    pane.classList.remove('active');
                }
            });
        });
    });

    // Demo Carousel Logic inside Artifact Previewer
    let currentSlide = 0;
    const slides = document.querySelectorAll('.carousel-slide');
    const indicator = document.querySelector('.carousel-indicator');
    const prevBtn = document.getElementById('carouselPrevBtn');
    const nextBtn = document.getElementById('carouselNextBtn');

    const updateCarousel = (index) => {
        slides.forEach((slide, i) => {
            if (i === index) {
                slide.classList.add('active');
            } else {
                slide.classList.remove('active');
            }
        });
        if (indicator) {
            indicator.textContent = `${index + 1} / ${slides.length}`;
        }
    };

    if (prevBtn && nextBtn) {
        prevBtn.addEventListener('click', () => {
            currentSlide = (currentSlide - 1 + slides.length) % slides.length;
            updateCarousel(currentSlide);
        });

        nextBtn.addEventListener('click', () => {
            currentSlide = (currentSlide + 1) % slides.length;
            updateCarousel(currentSlide);
        });
    }


    /* ==========================================================================
       3. Interactive Planning Mode Simulator
       ========================================================================== */
    const simSteps = document.querySelectorAll('.sim-step');
    const simPanes = document.querySelectorAll('.sim-panel');
    
    // Step 1 Elements
    const btnNextToStep2 = document.getElementById('btnNextToStep2');
    
    // Step 2 Elements
    const btnApprovePlan = document.getElementById('btnApprovePlan');
    const btnRejectPlan = document.getElementById('btnRejectPlan');
    
    // Step 3 Elements
    const btnNextToStep4 = document.getElementById('btnNextToStep4');
    const currentTaskText = document.getElementById('current-task-text');
    const loaderIcon = document.getElementById('loader-icon');
    const taskListItems = document.querySelectorAll('.task-tracker-mock li');
    
    // Step 4 Elements
    const btnRestartSim = document.getElementById('btnRestartSim');

    let simExecutionInterval = null;

    // Helper to transition simulator panels
    const transitionSimToStep = (stepNumber) => {
        // Update steps bar indicator
        simSteps.forEach((step, idx) => {
            const stepVal = idx + 1;
            step.classList.remove('active');
            if (stepVal < stepNumber) {
                step.classList.add('completed');
            } else if (stepVal === stepNumber) {
                step.classList.add('active');
                step.classList.remove('completed');
            } else {
                step.classList.remove('completed');
            }
        });

        // Update panel visibility
        simPanes.forEach(pane => {
            if (pane.id === `sim-panel-${stepNumber}`) {
                pane.classList.add('active');
            } else {
                pane.classList.remove('active');
            }
        });
    };

    // Step 1: Proceed to Step 2
    if (btnNextToStep2) {
        btnNextToStep2.addEventListener('click', () => {
            transitionSimToStep(2);
        });
    }

    // Step 2: Approve / Reject Plan
    if (btnRejectPlan) {
        btnRejectPlan.addEventListener('click', () => {
            alert('계획이 거절되었습니다. 에이전트 분석 콘솔이 다시 시작되며, 추가 설계를 제안하도록 요청합니다.');
            transitionSimToStep(1);
        });
    }

    if (btnApprovePlan) {
        btnApprovePlan.addEventListener('click', () => {
            transitionSimToStep(3);
            startSimulatedExecution();
        });
    }

    // Step 3: Simulate task runner execution
    const startSimulatedExecution = () => {
        // Reset step 3 mock items state to initial
        taskListItems[0].querySelector('.status-icon').className = 'status-icon done';
        taskListItems[0].querySelector('.status-icon').innerHTML = '<i class="fa-solid fa-square-check"></i>';
        
        taskListItems[1].querySelector('.status-icon').className = 'status-icon progress';
        taskListItems[1].querySelector('.status-icon').innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';
        currentTaskText.textContent = '스로틀 유틸리티 모듈 주입 중...';
        
        taskListItems[2].querySelector('.status-icon').className = 'status-icon pending';
        taskListItems[2].querySelector('.status-icon').innerHTML = '<i class="fa-regular fa-square"></i>';

        btnNextToStep4.disabled = true;
        btnNextToStep4.classList.add('disabled');
        btnNextToStep4.textContent = '작업 진행 중...';

        // Phase 1: Complete task 2 after 1.5 seconds
        setTimeout(() => {
            taskListItems[1].querySelector('.status-icon').className = 'status-icon done';
            taskListItems[1].querySelector('.status-icon').innerHTML = '<i class="fa-solid fa-square-check"></i>';
            
            // Start task 3
            taskListItems[2].querySelector('.status-icon').className = 'status-icon progress';
            taskListItems[2].querySelector('.status-icon').innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';
            
            // Phase 2: Complete task 3 after another 1.8 seconds
            setTimeout(() => {
                taskListItems[2].querySelector('.status-icon').className = 'status-icon done';
                taskListItems[2].querySelector('.status-icon').innerHTML = '<i class="fa-solid fa-square-check"></i>';
                
                // Enable next button
                btnNextToStep4.disabled = false;
                btnNextToStep4.classList.remove('disabled');
                btnNextToStep4.className = 'btn btn-primary';
                btnNextToStep4.innerHTML = '검증 및 완료 단계로 이동 <i class="fa-solid fa-arrow-right"></i>';
            }, 1800);
        }, 1500);
    };

    // Step 3 button action to go to Step 4
    if (btnNextToStep4) {
        btnNextToStep4.addEventListener('click', () => {
            transitionSimToStep(4);
        });
    }

    // Step 4: Restart Simulation
    if (btnRestartSim) {
        btnRestartSim.addEventListener('click', () => {
            transitionSimToStep(1);
        });
    }
});
